#' Calculate a point estimate of Fraction Unbound in Plasma (RED)
#'
#' This function use describing mass spectrometry (MS) peak areas
#' from samples collected as part of in vitro measurement of chemical fraction
#' unbound in plasma using rapid equilibrium dialysis (Waters, et al, 2008).
#' Data are read from a "Level2" text file that should have been formatted and created 
#' by \code{\link{format_fup_red}} (this is the "Level1" file). The Level1 file
#' should have been curated and had a column added with the value "Y" indicating
#' that each row is verified as usable for analysis (that is, the Level2 file).
#' 
#' The should be annotated according to
#' of these types:
#' \tabular{rrrrr}{
#'   Blank (ignored) \tab Blank\cr
#'   Plasma well concentration \tab Plasma\cr
#'   Phosphate-buffered well concentration\tab PBS\cr
#'   Time zero plasma concentration \tab T0\cr
#' }
#'
#' F_up is calculated from MS responses as:
#'
#' f_up = max(0,(mean(PBS Response * Dilution.Factor) - 
#'   mean(Blank Response * Dilution.Factor))) / (
#'   mean(Plasma Response * Dilution Factor) -
#'   mean(Blank Response * Dilution.Factor))
#'
#' @param FILENAME A string used to identify the input file, whatever the
#' argument given, "-PPB-RED-Level2.tsv" is appended (defaults to "MYDATA")
#' 
#' @param good.col Name of a column indicating which rows have been verified for 
#' analysis, indicated by a "Y" (Defaults to "Verified")
#'
#' @return \item{data.frame}{A data.frame in standardized format} 
#'
#' @author John Wambaugh
#'
#' @examples
#' red <- subset(wambaugh2019.red, Protein==100)
#' red$Date <- "2019"
#' red$Sample.Type <- "Blank"
#' red <- subset(red,!is.na(SampleName))
#' red[regexpr("PBS",red$SampleName)!=-1,"Sample.Type"] <- "PBS"
#' red[regexpr("Plasma",red$SampleName)!=-1,"Sample.Type"] <- "Plasma"
#' red$Dilution.Factor <- NA
#' red$Dilution.Factor <- as.numeric(red$Dilution.Factor)
#' red[red$Sample.Type=="PBS","Dilution.Factor"] <- 2
#' red[red$Sample.Type=="Plasma","Dilution.Factor"] <- 5
#' red[regexpr("T0",red$SampleName)!=-1,"Sample.Type"] <- "T0"
#' 
#' red$Test.Target.Conc <- 5
#' red$ISTD.Name <- "Bucetin and Diclofenac"
#' red$ISTD.Conc <- 1
#' red$Series <- 1
#' 
#' level1 <- format_fup_red(red,
#'   FILENAME="Wambaugh2019",
#'   sample.col="SampleName",
#'   compound.col="Preferred.Name",
#'   lab.compound.col="CompoundName",
#'   cal.col="RawDataSet")
#' 
#' level2 <- level1
#' level2$Verified <- "Y"
#' 
#' write.table(level2,
#'   file="Wambaugh2019-PPB-RED-Level2.tsv",
#'   sep="\t",
#'   row.names=F,
#'   quote=F)
#'   
#' level3 <- calc_fup_red_point(FILENAME="Wambaugh2019")
#' 
#' @references
#' Waters, Nigel J., et al. "Validation of a rapid equilibrium dialysis 
#' approach for the measurement of plasma protein binding." Journal of 
#' Pharmaceutical Sciences 97.10 (2008): 4586-4595.
#'
#' @export calc_fup_red_point
calc_fup_red_point <- function(FILENAME, good.col="Verified")
{
  PPB.data <- read.csv(file=paste(FILENAME,"-PPB-RED-Level2.tsv",sep=""), 
    sep="\t",header=T)  
  PPB.data <- subset(PPB.data,!is.na(Compound.Name))
  PPB.data <- subset(PPB.data,!is.na(Response))

# Standardize the column names:
  sample.col <- "Lab.Sample.Name"
  date.col <- "Date"
  compound.col <- "Compound.Name"
  dtxsid.col <- "DTXSID"
  lab.compound.col <- "Lab.Compound.Name"
  type.col <- "Sample.Type"
  dilution.col <- "Dilution.Factor"
  cal.col <- "Calibration"
  nominal.test.conc.col <- "Test.Target.Conc"
  istd.name.col <- "ISTD.Name"
  istd.conc.col <- "ISTD.Conc"
  istd.col <- "ISTD.Area"
  series.col <- "Series"
  area.col <- "Area"

# For a properly formatted level 2 file we should have all these columns:
  cols <-c(
    sample.col,
    date.col,
    compound.col,
    dtxsid.col,
    lab.compound.col,
    type.col,
    dilution.col,
    cal.col,
    nominal.test.conc.col,
    istd.name.col,
    istd.conc.col,
    istd.col,
    series.col,
    area.col,
    "Response",
    good.col)
  if (!(all(cols %in% colnames(PPB.data))))
  {
    warning("Run format_fup_red first (level 1) then curate to (level 2).")
    stop(paste("Missing columns named:",
      paste(cols[!(cols%in%colnames(PPB.data))],collapse=", ")))
  }

  # Only include the data types used:
  PPB.data <- subset(PPB.data,PPB.data[,type.col] %in% c(
    "Plasma","PBS","T0","Blank"))
  
  # Only used verfied data:
  PPB.data <- subset(PPB.data, PPB.data[,good.col] == "Y")

  out.table <-NULL
  num.chem <- 0
  num.cal <- 0
  for (this.chem in unique(PPB.data[,compound.col]))
  {
    this.subset <- subset(PPB.data,PPB.data[,compound.col]==this.chem)
    this.dtxsid <- this.subset$dtxsid[1]
    this.row <- c(this.subset[1,c(compound.col,dtxsid.col)],
      data.frame(Calibration="All Data",
        Fup=NaN))
    this.pbs <- subset(this.subset,Sample.Type=="PBS")
    this.plasma <- subset(this.subset,Sample.Type=="Plasma")
    this.blank <- subset(this.subset,Sample.Type=="Blank")
    if (length(unique(this.pbs$Dilution.Factor))>1) browser()
    df.pbs <- this.pbs$Dilution.Factor[1]
    if (length(unique(this.plasma$Dilution.Factor))>1) browser()
    df.plasma <- this.plasma$Dilution.Factor[1]
    
  # Check to make sure there are data for PBS and plasma: 
    if (dim(this.pbs)[1]> 0 & dim(this.plasma)[1] > 0 & dim(this.blank)[1] > 0 )
    {
      num.chem <- num.chem + 1
      this.row$Fup <- max(0,df.pbs*(mean(this.pbs$Response) -
        mean(this.blank$Response))) /
        (df.plasma*(mean(this.plasma$Response) -
        mean(this.blank$Response)))
      out.table <- rbind(out.table, this.row)
      print(paste(this.row$Compound.Name,"f_up =",signif(this.row$Fup,3)))
  # If fup is NA something is wrong, stop and figure it out:
      if(is.na(this.row$Fup)) browser()
  # If there are multiple measrument days, do separate calculations:
      if (length(unique(this.subset[,cal.col]))>1)
      {
        for (this.calibration in unique(this.subset[,cal.col]))
        {
          this.cal.subset <- subset(this.subset,
            this.subset[,cal.col]==this.calibration)
          this.row <- this.cal.subset[1,c(compound.col,dtxsid.col,cal.col)]
          this.pbs <- subset(this.cal.subset,Sample.Type=="PBS")
          this.plasma <- subset(this.cal.subset,Sample.Type=="Plasma")
          this.blank <- subset(this.cal.subset,Sample.Type=="Blank")
       # Check to make sure there are data for PBS and plasma: 
          if (dim(this.pbs)[1]> 0 & dim(this.plasma)[1] > 0 & dim(this.blank)[1] > 0)
          {
            this.row$Fup <- max(0,df.pbs*(mean(this.pbs$Response) -
              mean(this.blank$Response))) /
              (df.plasma*(mean(this.plasma$Response) -
              mean(this.blank$Response)))
            out.table <- rbind(out.table, this.row)
            num.cal <- num.cal + 1
          }
        }
      } else num.cal <- num.cal + 1
    }
  }

  rownames(out.table) <- make.names(out.table$Compound.Name, unique=TRUE)
  out.table <- apply(out.table,2,unlist) 
  out.table[,"Fup"] <- signif(as.numeric(out.table[,"Fup"]),3) 
  out.table <- as.data.frame(out.table)
  out.table$Fup <- as.numeric(out.table$Fup)
  
# Write out a "level 3" file (data organized into a standard format):  
  write.table(out.table, 
    file=paste(FILENAME,"-PPB-RED-Level3.tsv",sep=""),
    sep="\t",
    row.names=F,
    quote=F)
 
  print(paste("Fraction unbound values calculated for",num.chem,"chemicals."))
  print(paste("Fraction unbound values calculated for",num.cal,"measurements."))

  return(out.table)  
}



# invitroTKstats 0.0.13

* Initial CRAN submission
* Update documentation
* Standardization of column names across all assays, function arguments, and replicate types
* Creation of utility functions and data objects for nomenclature standardization
* Bug-fixes for in vitro toxicokinetic parameter estimates
* Addition of example datasets and vignettes
* Removal of automatic sigfig rounding for in R session output objects
* Citation update to BibTeX formatting
* Removal of unneccessary functions
* Addition of a data export argument

## ----load_packages, eval = TRUE-----------------------------------------------
    library(invitroTKstats)
    
    # There are multiple packages for loading Excel files, but I've been using this
    # one lately:
    library(readxl)

## ----clear_memory, eval = TRUE------------------------------------------------
    rm(list=ls())

## ----set_working_directory, eval = FALSE--------------------------------------
#      setwd("c:/users/jwambaug/git/invitroTKstats/working/KreutzPFAS")

## ----assay_information, eval=FALSE--------------------------------------------
#      CC.DILUTE <- 1*4
#      BLANK.DILUTE <- 1*4
#      AF.DILUTE <- 2*4
#      T5.DILUTE <- 10*4
#      T1.DILUTE <- 10*4
#      ANALYSIS.METHOD <- "GCMS"
#      ANALYSIS.INSTRUMENT <- "Agilent 8890 GC w 7010 triple quadrupole"
#      ISTD.CONC <- 1 # uM
#      UC.ASSAY.T0.CONC <- 10 # uM

## ----old_UC_scripts, eval = FALSE---------------------------------------------
#    suppressMessages(source("ak2.r"))
#    AK.UCdata$DTXSID <- NA
#    AK.UCdata[AK.UCdata$Lab.Compound.Name=="915","DTXSID"] <- "DTXSID4059914"
#    AK.UCdata[AK.UCdata$Lab.Compound.Name=="965","DTXSID"] <- "DTXSID60379269"
#    AK.UCdata[AK.UCdata$Lab.Compound.Name=="476","DTXSID"] <- "DTXSID40379666"
#    AK.UCdata[AK.UCdata$Lab.Compound.Name=="267","DTXSID"] <- "DTXSID10379991"
#    AK.UCdata[AK.UCdata$Lab.Compound.Name=="3125","DTXSID"] <- "DTXSID70381151"
#    AK.UCdata[AK.UCdata$Lab.Compound.Name=="906","DTXSID"] <- "DTXSID9059832"
#    AK.UCdata[AK.UCdata$Lab.Compound.Name=="273","DTXSID"] <- "DTXSID0059871"
#    AK.UCdata[AK.UCdata$Lab.Compound.Name=="913","DTXSID"] <- "DTXSID10382147"
#    AK.UCdata[AK.UCdata$Lab.Compound.Name=="4NT","DTXSID"] <- "DTXSID5023792"
#    AK.UCdata[AK.UCdata$Lab.Compound.Name=="899","DTXSID"] <- "DTXSID80382093"
#    AK.UCdata$Compound.Name <- NA
#    AK.UCdata[AK.UCdata$Lab.Compound.Name=="915","Compound.Name"] <-
#      "Heptafluorobutanol"
#    AK.UCdata[AK.UCdata$Lab.Compound.Name=="965","Compound.Name"] <-
#      "3-(Perfluoropropyl)propanol"
#    AK.UCdata[AK.UCdata$Lab.Compound.Name=="476","Compound.Name"] <-
#      "N-Methyl-N-trimethylsilylheptafluorobutyramide"
#    AK.UCdata[AK.UCdata$Lab.Compound.Name=="267","Compound.Name"] <-
#      "3-(Perfluorooctyl)propanol"
#    AK.UCdata[AK.UCdata$Lab.Compound.Name=="3125","Compound.Name"] <-
#      "Perfluorooctanamidine"
#    AK.UCdata[AK.UCdata$Lab.Compound.Name=="906","Compound.Name"] <-
#      "Dodecafluoroheptanol"
#    AK.UCdata[AK.UCdata$Lab.Compound.Name=="273","Compound.Name"] <-
#      "Pentafluoropropionamide"
#    AK.UCdata[AK.UCdata$Lab.Compound.Name=="913","Compound.Name"] <-
#      "3-(Perfluoro-2-butyl)propane-1,2-diol"
#    AK.UCdata[AK.UCdata$Lab.Compound.Name=="4NT","Compound.Name"] <-
#      "4-nitrotoluene"
#    AK.UCdata[AK.UCdata$Lab.Compound.Name=="899","Compound.Name"] <-
#      "2-Aminohexafluoropropan-2-ol"
#  
#  # Really one calibration:
#    AK.UCdata[AK.UCdata$Cal=="2020-02-04","Cal"] <- "2020-02-05"
#    AK.UCdata[AK.UCdata$Cal=="2020-02-24","Cal"] <- "2020-02-25"
#  
#    AK.UCdata[AK.UCdata$Type=="CC","Dilution.Factor"] <- CC.DILUTE
#    AK.UCdata[AK.UCdata$Type=="AF","Dilution.Factor"] <- AF.DILUTE
#    AK.UCdata[AK.UCdata$Type=="T1","Dilution.Factor"] <- T1.DILUTE
#    AK.UCdata[AK.UCdata$Type=="T5","Dilution.Factor"] <- T5.DILUTE
#    AK.UCdata$Level0.File <- "21220_915_965_476_267_906_273_913_899_900_analysis_090920.xlsx"
#    AK.UCdata$Level0.Sheet <- "UC Data"
#    AK.UCdata[AK.UCdata$Cal=="2020-02-25","Level0.Sheet"] <- "899_Data0225"
#    AK.UCdata$Target.Conc <- AK.UCdata$Target.Conc/1000
#  
#    level1.Dec2020 <- format_fup_uc(AK.UCdata,
#      FILENAME="KreutzDec2020",
#      sample.col="Name",
#      compound.col="Compound.Name",
#      lab.compound.col="Lab.Compound.Name",
#      type.col="Type",
#      std.conc.col="Target.Conc",
#      analysis.instrument.col="Instrument",
#      analysis.parameters.col="Analysis.Instrument.Param",
#      uc.assay.conc = 10
#      )
#  

## ----extract_899_900, eval=FALSE----------------------------------------------
#  this.file <- "021220_915_965_476_267_906_273_913_899_900_analysis_090920.xlsx"
#  this.sheet <- "899&900 Data"
#  analytes <- as.data.frame(read_excel(this.file, sheet=this.sheet,skip=1))
#  mfoet <-as.data.frame( read_excel(this.file, sheet="ControlChart_899&900_MFOET",skip=1))
#  this.data <- merge(analytes,mfoet)
#  this.chem.data <- this.data[,c("Name","Type","Acq. Date-Time","Area...17","RT...16","Resp.","Level")]
#  this.chem.data[regexpr("CC",this.chem.data$Name)!=-1,"Sample.Type"] <- "CC"
#  this.chem.data[regexpr("Blank",this.chem.data$Name)!=-1,"Sample.Type"] <- "CC"
#  this.chem.data[regexpr("AF",this.chem.data$Name)!=-1,"Sample.Type"] <- "AF"
#  this.chem.data[regexpr("T5",this.chem.data$Name)!=-1,"Sample.Type"] <- "T5"
#  this.chem.data[regexpr("T1",this.chem.data$Name)!=-1,"Sample.Type"] <- "T1"
#    this.chem.data[this.chem.data$Sample.Type=="CC","Dilution.Factor"] <- CC.DILUTE
#    this.chem.data[this.chem.data$Sample.Type=="AF","Dilution.Factor"] <- AF.DILUTE
#    this.chem.data[this.chem.data$Sample.Type=="T1","Dilution.Factor"] <- T1.DILUTE
#    this.chem.data[this.chem.data$Sample.Type=="T5","Dilution.Factor"] <- T5.DILUTE
#  this.chem.data[regexpr("A_GC",this.chem.data$Name)!=-1,"Series"] <- "A"
#  this.chem.data[regexpr("B_GC",this.chem.data$Name)!=-1,"Series"] <- "B"
#  this.chem.data[regexpr("C_GC",this.chem.data$Name)!=-1,"Series"] <- "C"
#  
#  
#    # Need to map cal curve levels back to concentrations:
#    CC.levels <- c(7,12,20,30,50,80,125,200,350,500,800,1500,2500,3500,5000)
#  this.chem.data$Conc <- sapply(this.chem.data$Level,function(x) CC.levels[as.numeric(x)])
#  this.chem.data[regexpr("Blank",this.chem.data$Name)!=-1,"Conc"] <- 0
#  this.chem.data$Lab.Compound.Name <- "900"
#  this.chem.data$DTXSID <- "DTXSID0059879"
#  this.chem.data$Compound.Name <- "1H,1H,5H-Perfluoropentanol"
#  this.chem.data$Date <-"2020-02-04"
#  this.chem.data$Note <- ""
#  this.chem.data$Level0.File <- this.file
#  this.chem.data$Level0.Sheet <- this.sheet
#  
#    level1.900 <- format_fup_uc(this.chem.data,
#      FILENAME="Kreutz9002020",
#      sample.col="Name",
#      compound.col="Compound.Name",
#      lab.compound.col="Lab.Compound.Name",
#      type.col="Sample.Type",
#      std.conc.col="Conc",
#      analysis.instrument=ANALYSIS.INSTRUMENT,
#      analysis.method="GCMS",
#      cal.col="Date",
#      istd.name="MFOET",
#      istd.conc=1,
#      istd.col="Resp.",
#      area.col="Area...17",
#      analysis.parameters.col="RT...16",
#      uc.assay.conc = 10
#      )

## ----old_uc_scripts2, eval = FALSE--------------------------------------------
#    suppressMessages(source("uc-test-AK.R"))
#    all.data$Analysis.Parameters <- apply(all.data,1,function(x) paste(
#      "Analyte RT",
#      signif(as.numeric(x[11]),5),
#      "ISTD RT:",
#      signif(as.numeric(x[15]),6)))
#    all.data$Level0.File <- "120619_PFAS_PPB_Amides_UC_AK_072020.xlsx"
#    all.data$Level0.Sheet <- "102919RawOutput"
#    all.data[all.data$Cal=="110119","Level0.Sheet"] <- "110119RawOutput"
#    all.data[all.data$Cal=="121019","Level0.Sheet"] <- "121019RawOutput"
#    all.data$Standard.Conc <- all.data$Standard.Conc/1000
#  
#    level1.Jul2020 <- format_fup_uc(all.data,
#                                    FILENAME="KreutzJul2020",
#                                    uc.assay.conc = 10,
#                                    area.col = "Chem.Area",
#                                    compound.col="Name",
#                                    std.conc.col="Standard.Conc",
#                                    note.col="Comment",
#                                    analysis.method="GCMS",
#                                    analysis.instrument="Agilent 8890 GC w 7010 triple quadrupole")

## ----old_pfoa_pfos_scripts, eval = FALSE--------------------------------------
#    suppressMessages(source("uc-test-052920.R"))
#    all.data$Lab.Compound.Name <- all.data$Compound.Name
#    all.data$Date <- "April2019"
#    all.data$DTXSID <- "DTXSID8031865"
#    all.data[all.data$Compound.Name=="PFOS","DTXSID"] <- "DTXSID3031864"
#    all.data$Compound.Name <- "Perfluorooctanoic acid"
#    all.data[all.data$DTXSID == "DTXSID3031864","Compound.Name"] <- "Perfluorooctanesulfonic acid"
#    all.data$Level0.File <- "20200402_PFAS_UC_PFOA_PFOS.xlsx"
#    all.data$Level0.Sheet <- "PFOA 4-12-19"
#    all.data[all.data$Cal=="100119","Level0.Sheet"] <- "PFOA 10-1-19"
#    all.data[all.data$Cal=="072319","Level0.Sheet"] <- "PFOS 7-23-19"
#    all.data[all.data$Cal=="010720","Level0.Sheet"] <- "PFOS 1-7-2020"
#    all.data[all.data$Type=="Blank", "Dilution.Factor"] <- BLANK.DILUTE
#    all.data[all.data$Type=="Blank", "Std. Conc"] <- 0
#  
#  
#    level1.May2020 <- format_fup_uc(all.data,
#                                    FILENAME="KreutzMay2020",
#                                    uc.assay.conc = 10,
#                                    area.col = "Area",
#                                    sample.col="Name",
#                                    note.col="Sample.Text",
#                                    compound.col="Compound.Name",
#                                    std.conc.col="Std. Conc",
#                                    analysis.parameters="RT",
#                                    analysis.method="GCMS",
#                                    analysis.instrument="Agilent 8890 GC w 7010 triple quadrupole",
#                                    date.col="Date",
#                                    istd.name="Unknown",
#                                    istd.col="IS.Area",
#                                    istd.conc=1)

## ----UC_data_files, eval=FALSE------------------------------------------------
#      files <- list("UC_474_760_3096_final.xlsx",
#                "UC_503_507_516_501_505_521_510_120721.xlsx",
#                "UC_513_268_275_812_121921.xlsx",
#                "UC_763_945_274_964_464_477_479_final-ak.xlsx",
#                "UC_959_949_final-ak.xlsx",
#                "UC_971_3135_941_902_956_3145_969_final_020322.xlsx"
#                )

## ----UC_chem_info, eval=FALSE-------------------------------------------------
#      chem.start <- c(37, 37, 37, 37, 38, 37)
#      cheminfo <- NULL
#      for (this.file in files)
#      {
#        these.chems <- as.data.frame(read_excel(this.file,
#                 sheet=1,
#                 skip = chem.start[which(files==this.file)]))
#        these.chems <- as.data.frame(subset(these.chems,
#                              regexpr("DTXSID",Analyte)!=-1))
#        this.reference <- NULL
#        for (this.row in 1:dim(these.chems)[1])
#        {
#          if (!is.na(these.chems[this.row,"Reference Compound"]))
#          {
#            this.reference <- these.chems[this.row,"Reference Compound"]
#          } else {
#            these.chems[this.row,"Reference Compound"] <- this.reference
#          }
#        }
#        this.istd <- NULL
#        for (this.row in 1:dim(these.chems)[1])
#        {
#          if (!is.na(these.chems[this.row,"IS"]))
#          {
#            this.istd<- these.chems[this.row,"IS"]
#          } else {
#            these.chems[this.row,"IS"] <- this.istd
#          }
#        }
#        these.chems$File <- this.file
#        this.date <- suppressWarnings(suppressMessages(as.data.frame(
#          read_excel(this.file,
#                 sheet=1,
#                 col_types="date",
#                 skip = 3))))[1,2]
#        if (this.file == "UC_908_909_916_923_3117_final-baw.xlsx") this.date <- "2019-09-01"
#        these.chems$Date <- this.date
#        if (!("Flags" %in% colnames(these.chems))) these.chems$Flags <- NA
#        if (!is.null(cheminfo)) these.chems <- these.chems[,colnames(cheminfo)]
#        cheminfo <- rbind(cheminfo,these.chems)
#      }
#  
#  
#  

## ----UC_control_info, eval=FALSE----------------------------------------------
#  for (this.file in files)
#  {
#    this.control <-
#      data.frame(
#        Analyte = "DTXSID5023792",
#        Name = "4-nitrotoluene",
#        'Sample ID' = "4NT",
#        IS = "13C6-4-nitrotoluene",
#        "Reference Compound" = NA,
#        "Avg. MW" = NA,
#        "Flags" = NA,
#        "File" = this.file)
#      this.control$Date <- suppressWarnings(suppressMessages(
#        as.data.frame(read_excel(this.file,
#                 sheet=1,
#                 col_types="date",
#                 skip = 3))))[1,2]
#      colnames(this.control)[3] <- "Sample ID"
#      colnames(this.control)[5] <- "Reference Compound"
#      colnames(this.control)[6] <- "Avg. MW"
#      cheminfo <- rbind(cheminfo,this.control)
#  }

## ----fprmat_dates, eval=FALSE-------------------------------------------------
#  cheminfo[,"Date"] <- sapply(cheminfo[,"Date"],function(x) gsub("  UTC","",x))

## ----UC_data_sheets, eval=FALSE-----------------------------------------------
#      UC.data <- NULL
#  
#      for (this.file in files)
#        if ("Data" %in% excel_sheets(this.file))
#        {
#            these.chems <- subset(cheminfo,File==this.file)
#            for (this.chem in unique(
#              these.chems$`Sample ID`))
#            {
#            these.data <- as.data.frame(
#              suppressMessages(read_excel(this.file,
#              sheet="Data")))
#            start.col.name <- paste(this.chem,"Method")
#            ANALYTE.OFFSET <- 4
#            ISTD.OFFSET <- 7
#            ANALYTE.RT.OFFSET <- 3
#            ISTD.RT.OFFSET <- 6
#            this.sheet <- "Data"
#            if (!(start.col.name %in% colnames(these.data)))
#            {
#              these.data <- as.data.frame(
#                suppressMessages(read_excel(this.file,
#                sheet="7bData")))
#              ANALYTE.OFFSET <- 3
#              ISTD.OFFSET <- 6
#              ANALYTE.RT.OFFSET <- 2
#              ISTD.RT.OFFSET <- 5
#              this.sheet <- "7bData"
#            }
#            first.col <- which(colnames(these.data)==start.col.name)
#            this.chem.data <- these.data[
#              ,c(first.col+ANALYTE.OFFSET,first.col+ISTD.OFFSET,first.col,3,7,6)]
#            colnames(this.chem.data) <- c(
#              "Area","ISTD.Area","NominConc","Lab.Sample.Name","Type","Note")
#            this.chem.data$UC.Assay.T0.Conc <- UC.ASSAY.T0.CONC
#            chem.index <- which(these.chems$`Sample ID` == this.chem)
#            this.chem.data$Compound.Name <- these.chems[chem.index,"Name"]
#            this.chem.data$Lab.Compound.Name <- this.chem
#            this.chem.data$DTXSID <- these.chems[chem.index,"Analyte"]
#            this.chem.data$ISTD.Name <- these.chems[chem.index,"IS"]
#            this.chem.data$ISTD.Conc <- ISTD.CONC
#            this.chem.data$Date <- these.chems[chem.index,"Date"]
#            this.chem.data$Cal <- this.chem.data$Date
#            this.chem.data$Analysis.Parameters <- paste(
#              "Analyte RT:",
#              signif(
#                suppressWarnings(as.numeric(
#                these.data[,first.col+ANALYTE.RT.OFFSET],5))),
#              "ISTD RT:",
#              signif(suppressWarnings(as.numeric(
#                these.data[,first.col+ISTD.RT.OFFSET],5)))
#              )
#            this.chem.data$Level0.File <- this.file
#            this.chem.data$Level0.Sheet <- this.sheet
#          UC.data <- rbind(UC.data,this.chem.data)
#          }
#        }

## ----UC_UC_474_760_3096_final, eval=FALSE-------------------------------------
#    this.file <- "UC_474_760_3096_final.xlsx"
#    these.chems <- subset(cheminfo,File==this.file)
#    new.data <- NULL
#    this.chem <- "474"
#    these.data <- as.data.frame(
#      suppressMessages(read_excel(this.file,
#      sheet="474Raw")))
#    these.data$Lab.Compound.Name <- this.chem
#    new.data <- rbind(new.data,these.data)
#    this.chem <- "760"
#    these.data <- as.data.frame(
#      suppressMessages(read_excel(this.file,
#      sheet="760Raw")))
#    these.data$Lab.Compound.Name <- this.chem
#    colnames(these.data) <- colnames(new.data)
#    new.data <- rbind(new.data,these.data)
#    this.chem <- "3096"
#    these.data <- as.data.frame(
#      suppressMessages(read_excel(this.file,
#      sheet="3096Raw")))
#    these.data$Lab.Compound.Name <- this.chem
#    colnames(these.data) <- colnames(new.data)
#    new.data <- rbind(new.data,these.data)
#    this.chem <- "4NT"
#    these.data <- as.data.frame(
#      suppressMessages(read_excel(this.file,
#      sheet="4NTRaw")))
#    these.data$A <- these.data[,22]
#    these.data$B <- NA
#    these.data$C <- NA
#    these.data$Lab.Compound.Name <- this.chem
#    colnames(these.data) <- colnames(new.data)
#    new.data <- rbind(new.data,these.data)
#    new.data <- subset(new.data,new.data[,3]!="Name")
#  
#    this.chem.data <- new.data[,
#      c(13,25,11,3,8,4)]
#    colnames(this.chem.data) <- c(
#      "Area","ISTD.Area","NominConc","Lab.Sample.Name","Type","Note")
#    this.chem.data$UC.Assay.T0.Conc <- UC.ASSAY.T0.CONC
#    for (this.chem in unique(new.data$Lab.Compound.Name))
#    {
#      which.rows <- new.data$Lab.Compound.Name == this.chem
#      chem.index <- which(these.chems$`Sample ID` == this.chem)
#  # Get rid of column header rows:
#      this.chem.data[which.rows, "Compound.Name"] <- these.chems[
#        chem.index,"Name"]
#      this.chem.data[which.rows, "Lab.Compound.Name"] <- this.chem
#      this.chem.data[which.rows, "DTXSID"] <- these.chems[
#        chem.index,"Analyte"]
#      this.chem.data[which.rows, "ISTD.Name"] <- these.chems[
#        chem.index,"IS"]
#      this.chem.data[which.rows, "ISTD.Conc"] <- ISTD.CONC
#      this.chem.data[which.rows, "Date"] <- these.chems[
#        chem.index,"Date"]
#    }
#    this.chem.data$Cal <- this.chem.data$Date
#    this.chem.data$Analysis.Parameters <- paste(
#              "Analyte RT:",
#              signif(suppressWarnings(as.numeric(
#                new.data[,12],5))),
#              "ISTD RT:",
#              signif(suppressWarnings(as.numeric(
#                new.data[,24],5)))
#              )
#    this.chem.data$Level0.File <- this.file
#    this.chem.data$Level0.Sheet <- sapply(this.chem.data$Lab.Compound.Name,
#                                          function(x)
#                                            paste(x,"Raw",sep=""))
#    UC.data <- rbind(UC.data,this.chem.data)
#    dim(UC.data)

## ----UC_763_945_274_964_464_477_479_final-ak, eval=FALSE----------------------
#    this.file <- "UC_763_945_274_964_464_477_479_final-ak.xlsx"
#    this.file.data <- NULL
#    these.chems <- subset(cheminfo,File==this.file)
#  
#  # Some, but not all data are on individual sheets:
#    this.chem <- "477"
#    these.data <- as.data.frame(
#      suppressMessages(read_excel(this.file,
#      sheet="477rerun_raw")))
#    this.chem.data <- these.data[,
#      c(14,17,10,3,7,4)]
#    colnames(this.chem.data) <- c(
#      "Area","ISTD.Area","NominConc","Lab.Sample.Name","Type","Note")
#    this.chem.data$Analysis.Parameters <- paste(
#      "Analyte RT:",
#      signif(suppressWarnings(as.numeric(
#      these.data[,13],5))),
#      "ISTD RT:",
#      signif(suppressWarnings(as.numeric(
#      these.data[,16],5)))
#      )
#    this.chem.data$Level0.Sheet <- "477rerun_raw"
#    this.chem.data$Lab.Compound.Name <- this.chem
#    this.chem.data$Note <- "477rerun"
#    this.file.data <- this.chem.data
#  
#    this.chem <- "4NT"
#    these.data <- as.data.frame(
#      suppressMessages(read_excel(this.file,
#      sheet="4NT_raw")))
#    this.chem.data <- these.data[,c(13,20,9,3,8,5)]
#    colnames(this.chem.data) <- c(
#      "Area","ISTD.Area","NominConc","Lab.Sample.Name","Type","Note")
#    this.chem.data$Analysis.Parameters <- paste(
#      "Analyte RT:",
#      signif(suppressWarnings(as.numeric(
#      these.data[,12],5))),
#      "ISTD RT:",
#      signif(suppressWarnings(as.numeric(
#      these.data[,19],5)))
#      )
#    this.chem.data$Level0.Sheet <- "4NT_raw"
#  # Need to map cal curve levels back to concentrations:
#    CC.levels <- c(5000,
#      3500,
#      2500,
#      1500,
#      800,
#      500,
#      350,
#      200,
#      125,
#      80,
#      50,
#      30,
#      20,
#      12,
#      7)
#    names(CC.levels) <- as.character(seq(15,1,-1))
#    this.chem.data[,"NominConc"] <- sapply(this.chem.data$NominConc,
#                                           function(x) CC.levels[x])
#    this.chem.data$Lab.Compound.Name <- this.chem
#  
#    this.file.data <- rbind(this.file.data,this.chem.data)
#  
#    # Four chemicals on sheet G4B_raw:
#    these.data <- as.data.frame(
#      suppressMessages(read_excel(this.file,
#      sheet="G4B_raw")))
#    # Discard data from 4/20 and 4/22:
#    these.data <- subset(these.data,
#      as.character(as.Date(as.numeric(these.data[,9]), origin = "1899-12-30")) ==
#        "2021-04-21")
#  
#  
#    for (this.chem in c("964","464","477","479"))
#    {
#      start.col <- which(colnames(these.data) == paste(this.chem,"Results"))
#      this.chem.data <- these.data[,c(start.col+3,start.col+6,8,3,7,4)]
#      colnames(this.chem.data) <- c(
#      "Area","ISTD.Area","NominConc","Lab.Sample.Name","Type","Note")
#      this.chem.data[,"NominConc"] <- sapply(this.chem.data$NominConc,
#                                             function(x) CC.levels[x])
#      this.chem.data$Analysis.Parameters<-apply(these.data,1,function(x)
#        paste("Analyte RT:",
#              signif(as.numeric(x[start.col+3]),5),
#              "ISTD RT:",
#              signif(as.numeric(x[start.col+6]),5)))
#      this.chem.data$Level0.Sheet <- "G4B_raw"
#      this.chem.data$Lab.Compound.Name <- this.chem
#      this.file.data <- rbind(this.file.data,this.chem.data)
#    }
#  
#    # Three chemicals on sheet G4A_raw:
#    these.data <- as.data.frame(
#      suppressMessages(read_excel(this.file,
#      sheet="G4A_raw")))
#    # Discard data from second run:
#    these.data <- these.data[1:36,]
#  
#    for (this.chem in c("763","945","274"))
#    {
#      start.col <- which(colnames(these.data) == paste(this.chem,"Results"))
#      this.chem.data <- these.data[,c(start.col+3,start.col+6,8,3,7,4)]
#      colnames(this.chem.data) <- c(
#      "Area","ISTD.Area","NominConc","Lab.Sample.Name","Type","Note")
#      this.chem.data[,"NominConc"] <- sapply(this.chem.data$NominConc,
#                                             function(x) CC.levels[x])
#      this.chem.data$Analysis.Parameters<-apply(these.data,1,function(x)
#        paste("Analyte RT:",
#              signif(as.numeric(x[start.col+3]),5),
#              "ISTD RT:",
#              signif(as.numeric(x[start.col+6]),5)))
#      this.chem.data$Level0.Sheet <- "G4A_raw"
#      this.chem.data$Lab.Compound.Name <- this.chem
#      this.file.data <- rbind(this.file.data,this.chem.data)
#    }
#  
#    this.file.data<- subset(this.file.data,Type!="Type")
#  
#    this.file.data$UC.Assay.T0.Conc <- UC.ASSAY.T0.CONC
#    for (this.chem in unique(this.file.data$Lab.Compound.Name))
#    {
#      which.rows <- this.file.data$Lab.Compound.Name == this.chem
#      chem.index <- which(these.chems$`Sample ID` == this.chem)
#  # Get rid of column header rows:
#      this.file.data[which.rows, "Compound.Name"] <- these.chems[
#        chem.index,"Name"]
#      this.file.data[which.rows, "Lab.Compound.Name"] <- this.chem
#      this.file.data[which.rows, "DTXSID"] <- these.chems[
#        chem.index,"Analyte"]
#      this.file.data[which.rows, "ISTD.Name"] <- these.chems[
#        chem.index,"IS"]
#      this.file.data[which.rows, "ISTD.Conc"] <- ISTD.CONC
#      this.file.data[which.rows, "Date"] <- these.chems[
#        chem.index,"Date"]
#    }
#    this.file.data$Cal <- this.file.data$Date
#    this.file.data$Level0.File <- this.file
#    this.file.data$Level0.Sheet <- "G4B_raw"
#    this.file.data[this.file.data$Lab.Compound.Name %in% c("763","945","274"),
#                   "Level0.Sheet"] <- "G4A_raw"
#    this.file.data[this.file.data$Lab.Compound.Name == "4NT", "Level0.Sheet"] <-
#      "4NT_raw"
#    this.file.data[is.na(this.file.data$Note),"Note"] <- ""
#    this.file.data[this.file.data$Note == "477rerun","Cal"] <- "070321"
#    this.file.data[this.file.data$Note == "477rerun","Date"] <- "070321"
#    this.file.data[this.file.data$Note == "477rerun","Level0.Sheet"] <-
#      "477rerun_raw"
#  
#  
#    UC.data <- rbind(UC.data,this.file.data[,colnames(UC.data)])
#    dim(UC.data)

## ----UC_959_949_final-ak.xlsx, eval=FALSE-------------------------------------
#    this.file <- "UC_959_949_final-ak.xlsx"
#    this.file.data <- NULL
#    these.chems <- subset(cheminfo,File==this.file)
#  
#    # Four chemicals on sheet G4B_raw:
#    these.data <- as.data.frame(
#      suppressMessages(read_excel(this.file,
#      sheet="RawData")))
#  
#    for (this.chem in c("959","4NT","949"))
#    {
#      start.col <- which(colnames(these.data) == paste(this.chem,"Results"))
#      this.chem.data <- these.data[,c(start.col+1,start.col+4,4,1,3,2)]
#      colnames(this.chem.data) <- c(
#      "Area","ISTD.Area","NominConc","Lab.Sample.Name","Type","Note")
#      this.chem.data[,"NominConc"] <- sapply(this.chem.data$NominConc,
#                                             function(x) CC.levels[x])
#      this.chem.data$Analysis.Parameters<-apply(these.data,1,function(x)
#        paste("Analyte RT:",
#              signif(as.numeric(x[start.col+0]),5),
#              "ISTD RT:",
#              signif(as.numeric(x[start.col+5]),5)))
#      this.chem.data$Level0.Sheet <- "RawData"
#      this.chem.data$Lab.Compound.Name <- this.chem
#      this.file.data <- rbind(this.file.data,this.chem.data)
#    }
#  
#    this.file.data<- subset(this.file.data,Type!="Type")
#  
#    this.file.data$UC.Assay.T0.Conc <- UC.ASSAY.T0.CONC
#    for (this.chem in unique(this.file.data$Lab.Compound.Name))
#    {
#      which.rows <- this.file.data$Lab.Compound.Name == this.chem
#      chem.index <- which(these.chems$`Sample ID` == this.chem)
#  # Get rid of column header rows:
#      this.file.data[which.rows, "Compound.Name"] <- these.chems[
#        chem.index,"Name"]
#      this.file.data[which.rows, "Lab.Compound.Name"] <- this.chem
#      this.file.data[which.rows, "DTXSID"] <- these.chems[
#        chem.index,"Analyte"]
#      this.file.data[which.rows, "ISTD.Name"] <- these.chems[
#        chem.index,"IS"]
#      this.file.data[which.rows, "ISTD.Conc"] <- ISTD.CONC
#      this.file.data[which.rows, "Date"] <- these.chems[
#        chem.index,"Date"]
#    }
#    this.file.data$Cal <- this.file.data$Date
#  
#    this.file.data$Level0.File <- this.file
#    this.file.data$Level0.Sheet <- "RawData"
#    UC.data <- rbind(UC.data,this.file.data[,colnames(UC.data)])
#    dim(UC.data)

## ----UC_971_3135_941_902_956_3145_969_final_020322, eval=FALSE----------------
#    this.file <- "UC_971_3135_941_902_956_3145_969_final_020322.xlsx"
#    this.file.data <- NULL
#    these.chems <- subset(cheminfo,File==this.file|"Sample ID"=="4NT")
#  
#    these.data <- as.data.frame(
#      suppressMessages(read_excel(this.file,
#                                  skip=1,
#      sheet="All Raw data and Calcs")))
#  
#    analyte.cols <- c("4NT...10","4:2FTOH...12","6:1FTOH...13","6:2FTOH...14",
#                      "4:4FTOH...15","8:2FTOH...16","7:3FTOH...17",
#                      "11:1FTOH...18")
#    chems <- c("4NT","4:2 FTOH aka 971","6:1 FTOH aka 3135",
#              "6:2 FTOH aka 941","4:4 FTOH aka 902","8:2 FTOH aka 956",
#              "7:3 FTOH aka 3145","11:1 FTOH aka 969")
#    istd.cols <- c("m4NT","m4:2 FTOH", "m6:2FTOH","m6:2FTOH","m6:2FTOH",
#              "m8:2FTOH","m8:2FTOH","m8:2FTOH")
#  
#    for (chem.index in 1:8)
#    {
#      this.chem <- chems[chem.index]
#      this.chem.data <- these.data[,c(
#        which(colnames(these.data)==analyte.cols[chem.index]),
#        which(colnames(these.data)==istd.cols[chem.index]),
#                                      4, 2, 3, 1)]
#      colnames(this.chem.data) <- c(
#      "Area","ISTD.Area","NominConc","Lab.Sample.Name","Type","Note")
#      this.chem.data$Analysis.Parameters<-these.data[1,analyte.cols[chem.index]]
#      this.chem.data$Level0.Sheet <- "All Raw data and Calcs"
#      this.chem.data$Lab.Compound.Name <- this.chem
#      this.file.data <- rbind(this.file.data,this.chem.data)
#    }
#  
#    this.file.data<- subset(this.file.data,!is.na(Type))
#    this.file.data<- subset(this.file.data,Type!="Sample")
#    this.file.data<- subset(this.file.data,!is.na(Lab.Sample.Name))
#    this.file.data[is.na(this.file.data$Note),"Note"]<-""
#  
#    this.file.data$UC.Assay.T0.Conc <- UC.ASSAY.T0.CONC
#    for (this.chem in unique(this.file.data$Lab.Compound.Name))
#    {
#      which.rows <- this.file.data$Lab.Compound.Name == this.chem
#      chem.index <- which(these.chems$`Sample ID` == this.chem)
#  # Get rid of column header rows:
#      this.file.data[which.rows, "Compound.Name"] <- these.chems[
#        chem.index,"Name"]
#      this.file.data[which.rows, "Lab.Compound.Name"] <- this.chem
#      this.file.data[which.rows, "DTXSID"] <- these.chems[
#        chem.index,"Analyte"]
#      this.file.data[which.rows, "ISTD.Name"] <- these.chems[
#        chem.index,"IS"]
#      this.file.data[which.rows, "ISTD.Conc"] <- ISTD.CONC
#      this.file.data[which.rows, "Date"] <- these.chems[
#        chem.index,"Date"]
#    }
#    this.file.data$Cal <- this.file.data$Date
#  
#    this.file.data$Analysis.Method <- "GCMS"
#    this.file.data$Analysis.Instrument <- "Agilent 8890 GC w 7010 triple quadrupole"
#    this.file.data$Level0.File <- this.file
#    this.file.data$Level0.Sheet <- "All Raw data and Calcs"
#    UC.data <- rbind(UC.data,this.file.data[,colnames(UC.data)])
#    dim(UC.data)

## ----UC_940_Athens_Mix1a__2020_Feb, eval=FALSE--------------------------------
#    this.file <- "UC_940_Athens_Mix1a__2020_Feb.xlsx"
#  # 940
#    this.row <- data.frame(Analyte="DTXSID3047558",
#                         Name="6:2 Fluorotelomer methacrylate",
#                         "Sample ID"="940",
#                         IS="m8:2FTOH",
#                         "Reference Compound"=NA,
#                         "Avg. MW"=432.181,
#                         Flags=NA,
#                         File=this.file,
#                         Date="2020-02-01")
#    colnames(this.row) <- colnames(cheminfo)
#    cheminfo <- rbind(cheminfo,this.row)
#  # 3203
#    this.row <- data.frame(Analyte="DTXSID3065586",
#                         Name="1H,1H-Perfluorobutyl methacrylate",
#                         "Sample ID"="3203",
#                         IS="m8:2FTOH",
#                         "Reference Compound"=NA,
#                         "Avg. MW"=268.131,
#                         Flags=NA,
#                         File=this.file,
#                         Date="2020-02-01")
#    colnames(this.row) <- colnames(cheminfo)
#    cheminfo <- rbind(cheminfo,this.row)
#  # 3142
#    this.row <- data.frame(Analyte="DTXSID00194615",
#                         Name="1H,1H,9H-Perfluorononyl acrylate",
#                         "Sample ID"="3142",
#                         IS="m8:2FTOH",
#                         "Reference Compound"=NA,
#                         "Avg. MW"=486.152,
#                         Flags=NA,
#                         File=this.file,
#                         Date="2020-02-01")
#    colnames(this.row) <- colnames(cheminfo)
#    cheminfo <- rbind(cheminfo,this.row)
#  
#    these.chems <- subset(cheminfo,File==this.file|"Sample ID"=="4NT")
#  
#    this.sheet <- "Data"
#    these.data <- as.data.frame(
#      suppressMessages(read_excel(this.file,
#      sheet=this.sheet,
#      skip=4)))
#  
#  
#    this.file.data <- NULL
#    chem.names <- c("940","3203","3142")
#    chem.cols <- colnames(these.data)[c(7,4,8)]
#    istd.col <- "...6"
#    conc.col <- "nm after crash"
#    sample.name.col <-"Sample Name"
#    for (this.chem.index in 1:length(chem.names))
#    {
#      this.chem <- chem.names[this.chem.index]
#      this.chem.data <- these.data[,c(
#        chem.cols[this.chem.index],
#        istd.col,
#        sample.name.col,
#        conc.col
#        )]
#      colnames(this.chem.data) <- c(
#        "Area","ISTD.Area","Lab.Sample.Name","NominConc")
#      this.chem.data <- subset(this.chem.data, !is.na(as.numeric(Area)))
#      this.chem.data$Lab.Compound.Name <- this.chem
#      chem.index <- which(these.chems$`Sample ID` == this.chem)
#  # Get rid of column header rows:t
#      this.chem.data[, "Compound.Name"] <- these.chems[
#        chem.index,"Name"]
#      this.chem.data[, "Lab.Compound.Name"] <- this.chem
#      this.chem.data[, "DTXSID"] <- these.chems[
#        chem.index,"Analyte"]
#      this.chem.data[, "ISTD.Name"] <- these.chems[
#        chem.index,"IS"]
#      this.chem.data[, "ISTD.Conc"] <- ISTD.CONC
#      this.chem.data[, "Date"] <- these.chems[
#        chem.index,"Date"]
#  
#      this.file.data <- rbind(this.file.data,this.chem.data)
#    }
#  
#    this.file.data$UC.Assay.T0.Conc <- UC.ASSAY.T0.CONC
#    this.file.data$Type <- this.chem.data$Lab.Sample.Name
#    this.file.data$Note <- ""
#    this.file.data$Cal <- this.file.data$Date
#    this.file.data$Analysis.Parameters<-""
#    this.file.data$Level0.Sheet <- this.sheet
#    this.file.data$Analysis.Method <- "GCMS"
#    this.file.data$Analysis.Instrument <- "Agilent 7890 GC w 7010 triple quadrupole"
#    this.file.data$Level0.File <- this.file
#  
#    UC.data <- rbind(UC.data,this.file.data[,colnames(UC.data)])
#    dim(UC.data)

## ----UC_276_467_Athens_Mix 2a and b20220913, eval=FALSE-----------------------
#    this.file <- "UC_276_467_Athens_Mix 2a and b20220913.xlsx"
#  # 276
#    this.row <- data.frame(Analyte="DTXSID5063235",
#                         Name="1H,1H-Perfluorooctyl methacrylate",
#                         "Sample ID"="276",
#                         IS="m6:2FTOH",
#                         "Reference Compound"=NA,
#                         "Avg. MW"=468.162,
#                         Flags=NA,
#                         File=this.file,
#                         Date="2020-02-01")
#  
#    colnames(this.row) <- colnames(cheminfo)
#    cheminfo <- rbind(cheminfo,this.row)
#  # 467
#    this.row <- data.frame(Analyte="DTXSID8062101",
#                         Name="8:2 Fluorotelomer methacrylate",
#                         "Sample ID"="467",
#                         IS="m6:2FTOH",
#                         "Reference Compound"=NA,
#                         "Avg. MW"=532.197,
#                         Flags=NA,
#                         File=this.file,
#                         Date="2020-02-01")
#    colnames(this.row) <- colnames(cheminfo)
#    cheminfo <- rbind(cheminfo,this.row)
#  # 471
#    this.row <- data.frame(Analyte="DTXSID10224331",
#                         Name="2,2,3,3-Tetrafluoropropyl acrylate",
#                         "Sample ID"="471",
#                         IS="m6:2FTOH",
#                         "Reference Compound"=NA,
#                         "Avg. MW"=186.106,
#                         Flags=NA,
#                         File=this.file,
#                         Date="2020-02-01")
#    colnames(this.row) <- colnames(cheminfo)
#    cheminfo <- rbind(cheminfo,this.row)
#  # 478
#    this.row <- data.frame(Analyte="DTXSID1068772",
#                         Name="2-(Perfluorobutyl)ethyl acrylate",
#                         "Sample ID"="478",
#                         IS="m6:2FTOH",
#                         "Reference Compound"=NA,
#                         "Avg. MW"=318.139,
#                         Flags=NA,
#                         File=this.file,
#                         Date="2020-02-01")
#    colnames(this.row) <- colnames(cheminfo)
#    cheminfo <- rbind(cheminfo,this.row)
#  # 468
#    this.row <- data.frame(Analyte="DTXSID5060986",
#                         Name="1H,1H,5H,5H-Perfluoro-1,5-pentanediol diacrylate",
#                         "Sample ID"="468",
#                         IS="m6:2FTOH",
#                         "Reference Compound"=NA,
#                         "Avg. MW"=320.187,
#                         Flags=NA,
#                         File=this.file,
#                         Date="2020-02-01")
#    colnames(this.row) <- colnames(cheminfo)
#    cheminfo <- rbind(cheminfo,this.row)
#  
#    these.chems <- subset(cheminfo,File==this.file|"Sample ID"=="4NT")
#  
#    this.sheet <- "Sheet 1_Mix 2a and b"
#    these.data <- as.data.frame(
#      suppressMessages(read_excel(this.file,
#      sheet=this.sheet,
#      skip=3)))
#  
#  
#    this.file.data <- NULL
#    chem.names <- c("471","478","468","276","467")
#    chem.cols <- colnames(these.data)[c(4,6,7,9,10)]
#    istd.col <- "8.4"
#    conc.col <- "nm after crash"
#    sample.name.col <-"RT"
#    for (this.chem.index in 1:length(chem.names))
#    {
#      this.chem <- chem.names[this.chem.index]
#      this.chem.data <- these.data[,c(
#        chem.cols[this.chem.index],
#        istd.col,
#        sample.name.col,
#        conc.col
#        )]
#      colnames(this.chem.data) <- c(
#        "Area","ISTD.Area","Lab.Sample.Name","NominConc")
#      this.chem.data <- subset(this.chem.data, !is.na(as.numeric(Area)))
#      this.chem.data$Lab.Compound.Name <- this.chem
#      chem.index <- which(these.chems$`Sample ID` == this.chem)
#  # Get rid of column header rows:t
#      this.chem.data[, "Compound.Name"] <- these.chems[
#        chem.index,"Name"]
#      this.chem.data[, "Lab.Compound.Name"] <- this.chem
#      this.chem.data[, "DTXSID"] <- these.chems[
#        chem.index,"Analyte"]
#      this.chem.data[, "ISTD.Name"] <- these.chems[
#        chem.index,"IS"]
#      this.chem.data[, "ISTD.Conc"] <- ISTD.CONC
#      this.chem.data[, "Date"] <- these.chems[
#        chem.index,"Date"]
#  
#      this.file.data <- rbind(this.file.data,this.chem.data)
#    }
#  
#    this.file.data$UC.Assay.T0.Conc <- UC.ASSAY.T0.CONC
#    this.file.data$Type <- this.chem.data$Lab.Sample.Name
#    this.file.data$Note <- ""
#    this.file.data$Cal <- this.file.data$Date
#    this.file.data$Analysis.Parameters<-""
#    this.file.data$Level0.Sheet <- this.sheet
#    this.file.data$Analysis.Method <- "GCMS"
#    this.file.data$Analysis.Instrument <- "Agilent 7890 GC w 7010 triple quadrupole"
#    this.file.data$Level0.File <- this.file
#  
#    UC.data <- rbind(UC.data,this.file.data[,colnames(UC.data)])
#    dim(UC.data)

## ----albrecht_data, eval = FALSE----------------------------------------------
#  data.guide <- as.data.frame(read_excel("dataguide-LA-UC.xlsx"))
#  new.row <- cheminfo[1,]
#  new.row[1,] <- NA
#  new.row[1,"Sample ID"] <- "3203"
#  new.row[1,"Name"] <- "1H,1H-Perfluorobutyl methacrylate"
#  cheminfo <- rbind(cheminfo,new.row)
#  
#  
#  la.uc <- merge_level0(data.label="KreutzPFASHep",
#  # describe the MS data table:
#               level0.catalog=data.guide,
#               sample.colname="Name",
#               type.colname="Type",
#               istd.col="ISTD.Name",
#               analysis.param.colname.col="Note.ColName",
#  # describe the chemical ID table:
#               chem.ids=cheminfo,
#               chem.lab.id.col="Sample ID",
#               chem.name.col="Name")

## ----UC_set_sample_types, eval=FALSE------------------------------------------
#  # Try again to get rid of column header rows:
#    UC.data <- subset(UC.data,Type!="Type")
#    dim(UC.data)
#  
#  # Make the peak area numeric and set a reasonable precision:
#    UC.data$Area <- signif(
#      suppressWarnings(as.numeric(UC.data$Area)))
#    UC.data$ISTD.Area <- signif(
#      suppressWarnings(as.numeric(UC.data$ISTD.Area)))
#  
#  # Annotate instrument:
#   UC.data$Analysis.Method <- ANALYSIS.METHOD
#    UC.data$Analysis.Instrument <- ANALYSIS.INSTRUMENT
#  
#    # Extract the sample type from column Sample Text:
#    for (this.replicate in c("a","b","c"))
#      for (this.type in c("T1","T5","AF"))
#      {
#        this.string <- paste(this.type,this.replicate,sep="")
#        which.rows <- regexpr(tolower(this.string),
#                        tolower(unlist(UC.data[,"Lab.Sample.Name"])))!=-1
#        which.rows <- which.rows | regexpr(tolower(this.string),
#                        tolower(unlist(UC.data[,"Type"])))!=-1
#        UC.data[which.rows, "Sample.Type"] <- this.type
#        UC.data[which.rows, "Replicate"] <- this.replicate
#  
#        for (this.series in 1:3)
#        {
#          this.string <- paste(this.type," S",this.series,this.replicate,sep="")
#          which.rows <- regexpr(tolower(this.string),
#                          tolower(unlist(UC.data[,"Lab.Sample.Name"])))!=-1
#          which.rows <- which.rows | regexpr(tolower(this.string),
#                        tolower(unlist(UC.data[,"Type"])))!=-1
#          UC.data[which.rows, "Sample.Type"] <- this.type
#          UC.data[which.rows, "Replicate"] <- this.replicate
#          UC.data[which.rows, "Series"] <- this.series
#  
#          this.string <- paste(this.type,"S",this.series,this.replicate,sep="")
#          which.rows <- regexpr(tolower(this.string),
#                          tolower(unlist(UC.data[,"Lab.Sample.Name"])))!=-1
#          which.rows <- which.rows | regexpr(tolower(this.string),
#                        tolower(unlist(UC.data[,"Type"])))!=-1
#          UC.data[which.rows, "Sample.Type"] <- this.type
#          UC.data[which.rows, "Replicate"] <- this.replicate
#          UC.data[which.rows, "Series"] <- this.series
#        }
#      }
#  
#    # Annotate series:
#    for (this.series in 1:3)
#    {
#      this.string <- paste("S",this.series,sep="")
#      which.rows <- regexpr(this.string, unlist(UC.data[,"Lab.Sample.Name"]))!=-1
#      UC.data[which.rows, "Series"] <- this.series
#    }
#  
#    UC.data[UC.data$Type == "Cal","Sample.Type"] <- "CC"
#    which.rows <- regexpr("cc",
#                    tolower(unlist(UC.data[,"Lab.Sample.Name"])))!=-1
#    which.rows <- which.rows | regexpr("cc",
#                    tolower(unlist(UC.data[,"Type"])))!=-1
#    UC.data[which.rows,"Sample.Type"] <- "CC"
#  
#    UC.data[UC.data$Type == "MatrixBlank","Sample.Type"] <- "Blank"
#    which.rows <- regexpr("mb",
#                    tolower(unlist(UC.data[,"Lab.Sample.Name"])))!=-1
#    which.rows <- which.rows | regexpr("mb",
#                    tolower(unlist(UC.data[,"Type"])))!=-1
#    UC.data[which.rows,"Sample.Type"] <-  "Blank"
#  
#  # Other Blank data:
#    which.rows <- regexpr("blank",
#                    tolower(unlist(UC.data[,"Lab.Sample.Name"])))!=-1 &
#                  is.na(unlist(UC.data[,"Sample.Type"]))
#    UC.data[which.rows,"Sample.Type"] <-  "CC"
#    UC.data[which.rows, "Series"] <- 1
#    UC.data[which.rows, "NominConc"] <- 0
#  # Other AF data:
#    which.rows <- regexpr("aq",
#                    tolower(unlist(UC.data[,"Lab.Sample.Name"])))!=-1 &
#                  is.na(unlist(UC.data[,"Sample.Type"]))
#    UC.data[which.rows,"Sample.Type"] <-  "AF"
#    UC.data[which.rows, "Series"] <- 1
#    which.rows <- regexpr("a9",
#                    tolower(unlist(UC.data[,"Lab.Sample.Name"])))!=-1 &
#                  is.na(unlist(UC.data[,"Sample.Type"]))
#    UC.data[which.rows,"Sample.Type"] <-  "AF"
#    UC.data[which.rows, "Series"] <- 1
#  # Other T1 data:
#    which.rows <- regexpr("t1",
#                    tolower(unlist(UC.data[,"Lab.Sample.Name"])))!=-1 &
#                  is.na(unlist(UC.data[,"Sample.Type"]))
#    UC.data[which.rows,"Sample.Type"] <-  "T1"
#    UC.data[which.rows, "Series"] <- 1
#  # Other T5 data:
#    which.rows <- regexpr("t5",
#                    tolower(unlist(UC.data[,"Lab.Sample.Name"])))!=-1 &
#                  is.na(unlist(UC.data[,"Sample.Type"]))
#    UC.data[which.rows,"Sample.Type"] <-  "T5"
#    UC.data[which.rows, "Series"] <- 1

## ----UC_drop_missing_sample_types, eval=FALSE---------------------------------
#    # Get rid of unused samples (QC samples):
#    UC.data <- subset(UC.data,!is.na(Sample.Type))

## ----UC_set_sample_types_metadata, eval=FALSE---------------------------------
#  # Convert to uM:
#    UC.data[,"Std.Conc"] <- suppressWarnings(as.numeric(UC.data[,"NominConc"]))/1000
#    UC.data[,"Std.Units"] <- "uM"
#    UC.data[UC.data[,"Sample.Type"]!="CC","Std.Units"] <- NA
#    UC.data[UC.data[,"Sample.Type"]!="CC","Std.Conc"] <- NA
#  
#  # We'll need to go back and set this per sample type:
#  UC.data[UC.data[,"Sample.Type"]=="AF","Dilution.Factor"] <- AF.DILUTE
#  UC.data[UC.data[,"Sample.Type"]=="T1","Dilution.Factor"] <- T1.DILUTE
#  UC.data[UC.data[,"Sample.Type"]=="T5","Dilution.Factor"] <- T5.DILUTE
#  UC.data[UC.data[,"Sample.Type"]=="CC","Dilution.Factor"] <- CC.DILUTE
#  UC.data[UC.data[,"Sample.Type"]=="Blank","Dilution.Factor"] <- BLANK.DILUTE
#  
#  # Treat the blanks as calibration data with concentration 0:
#  UC.data[UC.data[,"Sample.Type"]=="Blank","Std.Conc"] <- 0
#  UC.data[UC.data[,"Sample.Type"]=="Blank","Std.Units"] <- "uM"
#  
#  UC.data[UC.data[,"Sample.Type"]=="Blank","Sample.Type"] <- "CC"
#  dim(UC.data)

## ----remove bad CC samples, eval=FALSE----------------------------------------
#  # Get rid of CC samples that don't have a concentration:
#  UC.data <- subset(UC.data,!(Sample.Type=="CC" & is.na(Std.Conc)))
#  
#  dim(UC.data)
#  

## ----set_precision, eval = FALSE----------------------------------------------
#  for (this.col in c("Area", "ISTD.Area"))
#    UC.data[,this.col] <- signif(as.numeric(UC.data[,this.col]),6)

## ----format_and_annotate, eval=FALSE------------------------------------------
#      level1 <- format_fup_uc(UC.data,
#        FILENAME="KreutzPFAS",
#        sample.col="Lab.Sample.Name",
#        compound.col="Compound.Name",
#        std.conc.col="Std.Conc",
#        lab.compound.col="Lab.Compound.Name",
#        type.col="Sample.Type",
#        istd.col="ISTD.Area",
#        note.col="Note",
#        uc.assay.conc.col="UC.Assay.T0.Conc"
#        )
#  
#      level1 <- rbind(level1,level1.Jul2020,level1.Dec2020,level1.900)

## ----create_level2, eval=FALSE------------------------------------------------
#  #    write.table(UC.data,file="KreutzPFAS-fup-UC-Level1.tsv",sep="\t",row.names=FALSE)
#  
#      level2 <- level1
#      # Taking all data in spreadsheet as human verified for starters
#      level2$Verified <- "Y"
#      # From Anna:
#      # UC_513_268_275_812_121921.xlsx
#      # something appears off w/ AFS2a- exclude
#      which.rows <- regexpr("S2 AFa",level2$Lab.Sample.Name)!=-1 &
#        level2$Date == "2021-10-06"
#      level2[which.rows,"Verified"] <- "AK: something appears off w/ AFS2a"
#  
#      # From Anna:
#      # UC_971_3135_941_902_956_3145_969_final_020322.xlsx
#      # something appears off w/ AFS1a- exclude
#      which.rows <- level2$Date=="2021-09-13" &
#        level2$DTXSID %in% c("DTXSID1062122","DTXSID5044572") &
#        level2$Sample.Type=="AF" &
#        level2$Series == 1
#  
#      level2[which(which.rows)[seq(1,length(which(which.rows)),3)],"Verified"] <-
#        "AK: something appears off w/ AFS1a"
#  
#      # If not response in assay sample assume bad:
#      for (this.type in c("T1","T5"))
#      {
#        which.rows <- level2$Sample.Type==this.type & level2$Area==0
#        which.rows[is.na(which.rows)] <- FALSE
#        level2[which.rows,"Verified"] <- "JFW: Excluded for no response"
#      }
#  
#      # No cal curve 4NT (Nom.Conc >0, Area = 0):
#      which.rows <- level2$Lab.Sample.Name == "4NT" & level2$Area == 0
#      level2[which.rows,"Verified"] <- "JFW: Excluded, likely not analyzed"
#  
#      # Can't work without peak for ISTD:
#      which.rows <- level2$ISTD.Area == 0
#      level2[which.rows,"Verified"] <- "JFW: Excluded, no ISTD peak"

## ----bad_sample_annotate, eval=FALSE------------------------------------------
#  # 476, 3125, 273: only in S1
#  # 267, 906: only in S2
#  # 915, 965, 913: only in S3
#    level2[(regexpr("s2",tolower(level2$Lab.Sample.Name))!=-1 |
#            regexpr("s3",tolower(level2$Lab.Sample.Name))!=-1) &
#            level2$Lab.Compound.Name %in% c("476","3125","273"),
#           "Verified"] <- "JFW: Seems that test substance only in S1"
#    level2[(regexpr("s1",tolower(level2$Lab.Sample.Name))!=-1 |
#            regexpr("s3",tolower(level2$Lab.Sample.Name))!=-1) &
#            level2$Lab.Compound.Name %in% c("267","906"),
#           "Verified"] <- "JFW: Seems that test substance only in S2"
#    level2[(regexpr("s1",tolower(level2$Lab.Sample.Name))!=-1 |
#            regexpr("s2",tolower(level2$Lab.Sample.Name))!=-1) &
#            level2$Lab.Compound.Name %in% c("915","965","913"),
#           "Verified"] <- "JFW: Seems that test substance only in S3"
#    level2[regexpr("2a",tolower(level2$Lab.Sample.Name))!=-1 &
#            level2$Lab.Compound.Name %in% c("276","467"),
#           "Verified"] <- "JFW: Seems that test substance only in series B"

## ----badistd_detect, eval=FALSE-----------------------------------------------
#  ISTDTHRESH <- 10
#  gooddata <- level2$ISTD.Area
#  gooddata[is.na(gooddata)] <- ISTDTHRESH
#    level2[gooddata < ISTDTHRESH, "Verified"] <-
#      paste("Excluded for ISTD Peak smaller than", ISTDTHRESH)

## ----remove_nas, eval=FALSE---------------------------------------------------
#  level2[is.na(level2$Response),"Verified"] <- "JFW: Excluded for NA Response"
#  
#  #ccobs <- regexpr("CC",level2$Lab.Sample.Name)!=-1
#  #zeroobs <- level2$Area==0
#  #zeroobs[is.na(zeroobs)] <- FALSE
#  #blanks <- level2$Standard.Conc == 0
#  #blanks[is.na(blanks)] <- FALSE
#  
#  #level2[ccobs & zeroobs & !blanks,"Verified"] <-"JFW: Excluded cal curve no signal"
#  
#  for (this.id in c(
#    "DTXSID50369896",
#    "DTXSID3059927",
#    "DTXSID1047578",
#    "DTXSID30396867",
#    "DTXSID00380798",
#    "DTXSID30395037",
#    "DTXSID30340244"
#    ))
#  {
#    obsid <- level2$DTXSID==this.id
#    obszero <- level2$Area==0
#    obszero[is.na(obszero)] <- FALSE
#    level2[obsid & obszero, "Verified"] <-
#      "JFW: Excluded for lack of signal"
#  }

## ----outlier_detect, eval=FALSE-----------------------------------------------
#  R2THRESH <- 0.9
#  for (this.id in unique(level2$DTXSID))
#  {
#    these.cals <- unique(subset(level2, DTXSID==this.id)$Calibration)
#    for (this.cal in these.cals)
#    {
#      this.subset <- subset(level2,
#                            DTXSID == this.id &
#                            Calibration == this.cal &
#                            Sample.Type == "CC" &
#                            Verified == "Y")
#      if (dim(this.subset)[1] > 1)
#      {
#        this.fit <- lm(Response ~ Standard.Conc, data=this.subset)
#        while (summary(this.fit)$adj.r.squared < R2THRESH  &
#               dim(this.subset)[1] > 1 &
#               any(this.subset$Area>0))
#        {
#          cat(paste("Removing outliers for",this.id,"calibration",this.cal,"\n"))
#          bad.sample <- which(abs(this.fit$residuals) ==
#                                max(abs(this.fit$residuals)))
#          bad.name <- this.subset[bad.sample, "Lab.Sample.Name"]
#          level2[level2$DTXSID == this.id &
#                 level2$Calibration == this.cal &
#                 level2$Sample.Type == "CC" &
#                 level2$Lab.Sample.Name == bad.name,
#                 "Verified"] <- paste(
#                   "Excluded algorithmically as outlier (R2 < ",
#                   R2THRESH,")",sep="")
#          this.subset <- subset(level2,
#                                DTXSID == this.id &
#                                Calibration == this.cal &
#                                Sample.Type == "CC" &
#                                Verified == "Y")
#  
#          this.fit <- lm(Response ~ Standard.Conc, data=this.subset)
#        }
#        if (all(this.subset$Area==0))
#        {
#          level2[
#            level2$DTXSID == this.id &
#            level2$Calibration == this.cal &
#            level2$Sample.Type == "CC" &
#            level2$Verified == "Y", "Verified"] <-
#              "Excluded because remaining CC had area 0"
#        }
#     }
#  
#     # if (this.id== "DTXSID4059916") browser()
#    }
#  
#  }
#  

## ----cleanup_DTXSID20335129, eval=FALSE---------------------------------------
#  which.rows <- which(level2$DTXSID=="DTXSID20335129")
#  # Overule outlier detection:
#  level2[which.rows,"Verified"] <- "Y"
#  # Get rid of spike:
#  level2[level2$DTXSID=="DTXSID20335129" &
#         level2$Lab.Sample.Name=="UCCC spike", "Verified"] <- "Spike"
#  level2[which.rows[24:29], "Verified"] <- "Extra CC"

## ----load_preprocessed_data_from_package, eval=TRUE---------------------------
level2 <- invitroTKstats::kreutz2023.uc

## ----write_level2, eval=TRUE--------------------------------------------------
write.table(level2,
      file="KreutzPFAS-fup-UC-Level2.tsv",
      sep="\t",
      row.names=F,
      quote=F)

## ----MLE, eval=TRUE-----------------------------------------------------------
    level3 <- calc_fup_uc_point(FILENAME="KreutzPFAS") 

## ----Bayes, eval=FALSE--------------------------------------------------------
#  rm(list=ls())
#  library(invitroTKstats)
#  setwd("c:/users/jwambaug/git/invitroTKstats/working/KreutzPFAS/")
#  level4 <- calc_fup_uc(FILENAME="KreutzPFAS",
#                        NUM.CORES=8,
#                        JAGS.PATH="C:/Users/jwambaug/AppData/Local/JAGS/JAGS-4.3.0/x64")


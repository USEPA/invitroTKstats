## ----load_packages, eval = TRUE-----------------------------------------------
    library(invitroTKstats)
    
    # There are multiple packages for loading Excel files, but I've been using this
    # one lately:
    library(readxl)

## ----clear_memory, eval = TRUE------------------------------------------------
    rm(list=ls())

## ----set_working_directory, eval = FALSE--------------------------------------
#      setwd("c:/users/jwambaug/git/invitroTKstats/working/KreutzPFAS")

## ----assay_information, eval=FALSE--------------------------------------------
#      CC.DILUTE <- 240
#      BLANK.DILUTE <- 480
#      CVST.DILUTE <- 480
#      INACTIVE.DILUTE <- 480
#      ANALYSIS.METHOD <- "UPLC-MS/MS"
#      ANALYSIS.INSTRUMENT <- "Waters Xevo TQ-S micro (QEB0036)"
#      ISTD.CONC <- 10/1000 # uM
#      CLINT.ASSAY.CONC <- 1 # uM

## ----test_Chemicals, eval=FALSE-----------------------------------------------
#  chem.ids <- read_excel("GCMS-PFAS_Data_Summary-toJFW.xlsx", sheet=1)
#  chem.ids <- as.data.frame(chem.ids)
#  # Deal with "or" statements in chemical ids:
#  for (this.row in 1:dim(chem.ids)[1])
#  {
#    if (!is.na(chem.ids[this.row, "Abbrev_SPID"]))
#      if (regexpr("or", chem.ids[this.row,"Abbrev_SPID"])!=-1)
#      {
#        ids <- strsplit(chem.ids[this.row,"Abbrev_SPID"]," or ")
#        if (length(ids[[1]])>1)
#        for (this.id in ids[[1]])
#        {
#          this.id <- gsub(";","",this.id)
#          this.id <- gsub("\\?\\)","",this.id)
#          new.row <- chem.ids[this.row,]
#          new.row[,"Abbrev_SPID"] <- this.id
#          chem.ids <- rbind(chem.ids,new.row)
#        }
#        ids <- strsplit(chem.ids[this.row,"Abbrev_SPID"]," \\(or ")
#        if (length(ids[[1]])>1)
#        for (this.id in ids[[1]])
#        {
#          this.id <- gsub(";","",this.id)
#          this.id <- gsub("\\?\\)","",this.id)
#          new.row <- chem.ids[this.row,]
#          new.row[,"Abbrev_SPID"] <- this.id
#          chem.ids <- rbind(chem.ids,new.row)
#        }
#      }
#  }
#  new.row <- chem.ids[1,]
#  new.row[,] <- NA
#  new.row[,"DTXSID"] <- "DTXSID1023869"
#  new.row[,2]<- "Ametryn"
#  new.row[,4]<- "Ametryn"
#  chem.ids <- rbind(chem.ids,new.row)

## ----compile_data, eval=FALSE-------------------------------------------------
#  data.guide <- as.data.frame(read_excel("dataguide-AK-hep.xlsx"))
#  
#  ak.hep <- merge_level0(data.label="KreutzPFASHep",
#  # describe the MS data table:
#               level0.catalog=data.guide,
#               sample.colname="Name",
#               type.colname="Type",
#               istd.col="ISTD.Name",
#               analysis.param.colname.col="Note.ColName",
#  # describe the chemical ID table:
#               chem.ids=chem.ids,
#               chem.lab.id.col="Abbrev_SPID",
#               chem.name.col="Chemical Name (Common Abbreviation)")

## ----annotate_sample_type, eval=FALSE-----------------------------------------
#  ak.hep <- subset(ak.hep,!is.na(Type))
#  ak.hep[ak.hep$Type == "Cal", "Sample.Type"] <- "CC"
#  ak.hep[regexpr("cc",tolower(ak.hep[,"Sample"]))!=-1, "Sample.Type"] <- "CC"
#  ak.hep[ak.hep$Type == "MatrixBlank", "Sample.Type"] <- "Blank"
#  ak.hep[regexpr("blank",tolower(ak.hep[,"Sample"]))!=-1, "Sample.Type"] <- "Blank"
#  ak.hep[regexpr("mb",tolower(ak.hep[,"Sample"]))!=-1, "Sample.Type"] <- "Blank"
#  ak.hep[regexpr("spike",tolower(ak.hep[,"Sample"]))!=-1,
#                 "Sample.Type"] <- "Blank"
#  
#  # Figure out from sample name whether the hepatocytes were alive:
#  # Indicate whether hepatocytes have been inactivated:
#  ak.hep$Active.Hep <- NA

## ----annotate_sample_time, eval=FALSE-----------------------------------------
#  ak.hep <- subset(ak.hep,!is.na(ak.hep[,"Sample"]))
#  ak.hep[,"Time"] <- NA
#  ak.hep[regexpr("t240",tolower(ak.hep[,"Sample"]))!=-1,"Time"] <- 240/60
#  ak.hep[regexpr("t120",tolower(ak.hep[,"Sample"]))!=-1,"Time"] <- 120/60
#  ak.hep[regexpr("t60",tolower(ak.hep[,"Sample"]))!=-1,"Time"] <- 60/60
#  ak.hep[regexpr("t30",tolower(ak.hep[,"Sample"]))!=-1,"Time"] <- 30/60
#  ak.hep[regexpr("t15",tolower(ak.hep[,"Sample"]))!=-1,"Time"] <- 15/60
#  ak.hep[regexpr("t0",tolower(ak.hep[,"Sample"]))!=-1,"Time"] <- 0/60
#  ak.hep[ak.hep$Lab.Compound.ID=="971" & regexpr("_240",tolower(ak.hep[,"Sample"]))!=-1,"Time"] <- 240/60
#  ak.hep[ak.hep$Lab.Compound.ID=="971" & regexpr("_120",tolower(ak.hep[,"Sample"]))!=-1,"Time"] <- 120/60
#  ak.hep[ak.hep$Lab.Compound.ID=="971" & regexpr("_60",tolower(ak.hep[,"Sample"]))!=-1,"Time"] <- 60/60
#  ak.hep[ak.hep$Lab.Compound.ID=="971" & regexpr("_30",tolower(ak.hep[,"Sample"]))!=-1,"Time"] <- 30/60
#  ak.hep[ak.hep$Lab.Compound.ID=="971" & regexpr("_15",tolower(ak.hep[,"Sample"]))!=-1,"Time"] <- 15/60
#  ak.hep[ak.hep$Lab.Compound.ID=="971" & regexpr("_0",tolower(ak.hep[,"Sample"]))!=-1,"Time"] <- 0/60
#  # See platemap on sheet "Assay Summary" to extract time points:
#  ak.hep[ak.hep$Level0.File %in% c("Hep_908_909_916_923_final.xlsx",
#         "Hep_913_AK_082421.xlsx") &
#         regexpr("tmid",tolower(ak.hep[,"Sample"]))!=-1 &
#         (regexpr("1_",tolower(ak.hep[,"Sample"]))!=-1 |
#         regexpr("2_",tolower(ak.hep[,"Sample"]))!=-1 |
#         regexpr("3_",tolower(ak.hep[,"Sample"]))!=-1), "Time"] <- 15/60
#  ak.hep[ak.hep$Level0.File %in% c("Hep_908_909_916_923_final.xlsx",
#         "Hep_913_AK_082421.xlsx") &
#         regexpr("tmid",tolower(ak.hep[,"Sample"]))!=-1 &
#         (regexpr("4_",tolower(ak.hep[,"Sample"]))!=-1 |
#         regexpr("5_",tolower(ak.hep[,"Sample"]))!=-1 |
#         regexpr("6_",tolower(ak.hep[,"Sample"]))!=-1), "Time"] <- 30/60
#  ak.hep[ak.hep$Level0.File %in% c("Hep_908_909_916_923_final.xlsx",
#         "Hep_913_AK_082421.xlsx") &
#         regexpr("tmid",tolower(ak.hep[,"Sample"]))!=-1 &
#         (regexpr("7_",tolower(ak.hep[,"Sample"]))!=-1 |
#         regexpr("8_",tolower(ak.hep[,"Sample"]))!=-1 |
#         regexpr("9_",tolower(ak.hep[,"Sample"]))!=-1), "Time"] <- 60/60
#  ak.hep[ak.hep$Level0.File %in% c("Hep_908_909_916_923_final.xlsx",
#         "Hep_913_AK_082421.xlsx") &
#         regexpr("tmid",tolower(ak.hep[,"Sample"]))!=-1 &
#         (regexpr("10_",tolower(ak.hep[,"Sample"]))!=-1 |
#         regexpr("11_",tolower(ak.hep[,"Sample"]))!=-1 |
#         regexpr("12_",tolower(ak.hep[,"Sample"]))!=-1), "Time"] <- 120/60

## ----annotate_cvst_inactive, eval=FALSE---------------------------------------
#  # Initially mark all samples with a time as "Cvt"
#  ak.hep[!is.na(ak.hep[,"Time"]),"Sample.Type"] <- "Cvst"
#  
#  # Differentiate live hepatocytes from inactive:
#  ak.hep[ak.hep[,"Sample.Type"] %in% "Cvst", "Active.Hep"] <- 1
#  ak.hep[regexpr("hitc",tolower(ak.hep[,"Sample"]))!=-1,
#    "Active.Hep"] <- 0
#  ak.hep[regexpr("inactive",tolower(ak.hep[,"Sample"]))!=-1,
#    "Active.Hep"] <- 0
#  ak.hep[ak.hep$Level0.File %in% c("Hep_908_909_916_923_final.xlsx",
#         "Hep_913_AK_082421.xlsx") &
#         regexpr("t0",tolower(ak.hep[,"Sample"]))!=-1 &
#         (regexpr("4_",tolower(ak.hep[,"Sample"]))!=-1 |
#         regexpr("5_",tolower(ak.hep[,"Sample"]))!=-1 |
#         regexpr("6_",tolower(ak.hep[,"Sample"]))!=-1), "Active.Hep"] <- 0
#  ak.hep[ak.hep$Level0.File %in% c("Hep_908_909_916_923_final.xlsx",
#         "Hep_913_AK_082421.xlsx") &
#         regexpr("t240",tolower(ak.hep[,"Sample"]))!=-1 &
#         (regexpr("4_",tolower(ak.hep[,"Sample"]))!=-1 |
#         regexpr("5_",tolower(ak.hep[,"Sample"]))!=-1 |
#         regexpr("6_",tolower(ak.hep[,"Sample"]))!=-1), "Active.Hep"] <- 0
#  ak.hep[
#    sapply(ak.hep$Active.Hep,function(x) ifelse(is.na(x),FALSE,x==0)),
#    "Sample.Type"] <- "Inactive"

## ----annotate_dilution_facor, eval=FALSE--------------------------------------
#  ak.hep$Dilution.Factor <- NA
#  ak.hep[ak.hep$Sample.Type %in% "Blank",
#    "Dilution.Factor"] <- BLANK.DILUTE
#  ak.hep[ak.hep$Sample.Type %in% "CC",
#    "Dilution.Factor"] <- CC.DILUTE
#  ak.hep[ak.hep$Sample.Type %in% "Cvst",
#    "Dilution.Factor"] <- CVST.DILUTE
#  ak.hep[ak.hep$Sample.Type %in% "Inactive",
#    "Dilution.Factor"] <- INACTIVE.DILUTE

## ----cleanup_analyte_peaks, eval=FALSE----------------------------------------
#  ak.hep$Peak.Area <- as.numeric(ak.hep$Peak.Area)
#  ak.hep[,"ISTD.Peak.Area"] <- as.numeric(ak.hep[,"ISTD.Peak.Area"])
#  ak.hep[,"Compound.Conc"] <- as.numeric(ak.hep[,"Compound.Conc"])
#  ak.hep <- subset(ak.hep, !is.na(Peak.Area) &
#    !is.na(ak.hep[,"ISTD.Peak.Area"]))

## ----convert_units_for_standard, eval=FALSE-----------------------------------
#  ak.hep[,"Compound.Conc"] <- as.numeric(ak.hep[,"Compound.Conc"])/1000

## ----annotate_sample_notes, eval=FALSE----------------------------------------
#  ak.hep$Note <-NA

## ----remove_missing_istd, eval=FALSE------------------------------------------
#  ak.hep <- subset(ak.hep, ISTD.Peak.Area>0)

## ----set_precision, eval = FALSE----------------------------------------------
#  for (this.col in c("Peak.Area", "ISTD.Peak.Area", "Analysis.Params"))
#    ak.hep[,this.col] <- signif(as.numeric(ak.hep[,this.col]),6)

## ----format_and_annotate, eval=FALSE------------------------------------------
#  level1 <- format_clint(ak.hep,
#    FILENAME="KreutzPFASHep",
#    sample.col ="Sample",
#    date.col="Date",
#    compound.col="Compound",
#    lab.compound.col="Lab.Compound.ID",
#    type.col="Sample.Type",
#    dilution.col="Dilution.Factor",
#    cal.col="Date",
#    istd.conc = ISTD.CONC,
#    area.col="Peak.Area",
#    istd.col= "ISTD.Peak.Area",
#    density = 0.5,
#    clint.assay.conc = CLINT.ASSAY.CONC,
#    std.conc.col="Compound.Conc",
#    time.col = "Time",
#    analysis.method = ANALYSIS.METHOD,
#    analysis.instrument = ANALYSIS.INSTRUMENT,
#    analysis.parameters.col = "Analysis.Params"
#    )

## ----create_level2, eval=FALSE------------------------------------------------
#  level2 <- level1
#  level2$Verified <- "Y"
#  
#  level2[level2[,"Level0.File"]=="G6HC_474_3096_101621_final.xlsx" &
#         level2[,"Lab.Compound.Name"]=="760", "Verified"] <- "Not present"
#  level2[level2[,"Level0.File"]=="G6HC_474_3096_101621_final.xlsx" &
#         regexpr("474",level2[,"Lab.Sample.Name"])!=-1 &
#         level2[,"Lab.Compound.Name"]!="474", "Verified"] <- "Not present"
#  level2[level2[,"Level0.File"]=="G6HC_474_3096_101621_final.xlsx" &
#         regexpr("3096",level2[,"Lab.Sample.Name"])!=-1 &
#         level2[,"Lab.Compound.Name"]!="3096", "Verified"] <- "Not present"
#  level2[regexpr("qc",tolower(level2[,"Lab.Sample.Name"]))!=-1,
#                 "Verified"] <- "Quality Control"
#  level2[regexpr("media",tolower(level2[,"Lab.Sample.Name"]))!=-1,
#                 "Verified"] <- "Media Only"
#  level2[tolower(level2[,"Lab.Sample.Name"])=="acn",
#                 "Verified"] <- "Acetonitrile"
#  level2[level2$Lab.Sample.Name %in% c(
#                                       "899",
#                                       "900",
#                                       "906",
#                                       "476",
#                                       "267",
#                                       "913",
#                                       "965"), "Verified"] <-
#                                       "Not sure what these are"
#  for (this.chem in c("745","949","959"))
#  {
#    level2[level2$Level0.File=="Hep_745_949_959_082421_final.xlsx" &
#           regexpr(this.chem,level2$Lab.Sample.Name)==-1 &
#           level2$Lab.Compound.Name==this.chem &
#           level2$Sample.Type %in% c("Cvst","Inactive"),
#           "Verified"] <- "Compound not present"
#  }
#  level2[level2$Level0.File=="Hep_945_274_464_477_479_final.xlsx" &
#         level2$Level0.Sheet=="Data_B" &
#         level2$Sample.Type != "Blank" &
#         level2$Area == 0,
#         "Verified"] <- "Compound not present"
#  level2[level2$Level0.File=="Hep_745_949_959_082421_final.xlsx" &
#         level2$Level0.Sheet=="Data071421" &
#         level2$Sample.Type != "Blank" &
#         level2$Area == 0,
#         "Verified"] <- "Compound not present"
#  level2[level2$Level0.File %in% c("Hep_908_909_916_923_final.xlsx",
#         "Hep_913_AK_082421.xlsx") &
#         regexpr("t0",tolower(level2[,"Lab.Sample.Name"]))!=-1 &
#         (regexpr("7_",tolower(level2[,"Lab.Sample.Name"]))!=-1 |
#         regexpr("8_",tolower(level2[,"Lab.Sample.Name"]))!=-1 |
#         regexpr("9_",tolower(level2[,"Lab.Sample.Name"]))!=-1), "Verified"] <- "Media Only"
#  level2[level2$Level0.File %in% c("Hep_908_909_916_923_final.xlsx",
#         "Hep_913_AK_082421.xlsx") &
#         regexpr("t240",tolower(level2[,"Lab.Sample.Name"]))!=-1 &
#         (regexpr("7_",tolower(level2[,"Lab.Sample.Name"]))!=-1 |
#         regexpr("8_",tolower(level2[,"Lab.Sample.Name"]))!=-1 |
#         regexpr("9_",tolower(level2[,"Lab.Sample.Name"]))!=-1), "Verified"] <- "Media Only"
#                    	
#  
#  
#  #level2[level2[,"Lab.Compound.Name"]=="745", "Verified"] <- "Unstable"
#  level2[level2[,"Lab.Compound.Name"]=="959", "Verified"] <- "Unstable"
#  #level2[level2[,"Lab.Compound.Name"]=="30503", "Verified"] <- "Unstable"
#  #level2[level2[,"Lab.Compound.Name"]=="30507", "Verified"] <- "Unstable"
#  #level2[level2[,"Lab.Compound.Name"]=="30516", "Verified"] <- "Unstable"
#  #level2[level2[,"Lab.Compound.Name"]=="30501", "Verified"] <- "Unstable"
#  #level2[level2[,"Lab.Compound.Name"]=="900", "Verified"] <- "Unstable"
#  #level2[level2[,"Lab.Compound.Name"]=="476", "Verified"] <- "Unstable"
#  #level2[level2[,"Lab.Compound.Name"]=="905", "Verified"] <- "Unstable"
#  #level2[level2[,"Lab.Compound.Name"]=="965", "Verified"] <- "Unstable"
#  #level2[level2[,"Lab.Compound.Name"]=="474", "Verified"] <- "Unstable"
#  #level2[level2[,"Lab.Compound.Name"]=="3096", "Verified"] <- "Unstable"

## ----manual_curation, eval=FALSE----------------------------------------------
#  level2[level2$Verified=="Y","Verifed"] <- "Manually omitted BAW"
#  level2[level2$DTXSID %in% c(
#    "DTXSID0059871",
#    "DTXSID3059927",
#    "DTXSID80310730",
#    "DTXSID70381090",
#    "DTXSID10382147",
#    "DTXSID70366226",
#    "DTXSID2060965",
#    "DTXSID30396867",
#    "DTXSID00380798",
#    "DTXSID30340244",
#    "DTXSID60400587",
#    "DTXSID1062122",
#    "DTXSID50369896"), "Verified"] <- "Y"
#  

## ----load_preprocessed_data_from_package, eval=TRUE---------------------------
level2 <- invitroTKstats::kreutz2023.clint

## ----write_level2, eval=FALSE-------------------------------------------------
#  write.table(level2,
#    file="KreutzPFAS-Clint-Level2.tsv",
#    sep="\t",
#    row.names=F,
#    quote=F)

## ----plot_level2, eval=TRUE---------------------------------------------------
for (this.id in unique(level2$DTXSID))
{
  this.subset <- subset(level2,DTXSID==this.id)
  plot(this.subset$Time,this.subset$Area,main=unique(this.subset$Compound.Name))
}
this.subset <- subset(level2,DTXSID==unique(level2$DTXSID)[3])
plot(this.subset$Time,this.subset$Area,main=unique(this.subset$Compound.Name))
# If units are right then we should have the same calibration for CC and Cvst:
subset(this.subset,Sample.Type=="CC")$Response/
  subset(this.subset,Sample.Type=="CC")$Std.Conc*
  subset(this.subset,Sample.Type=="CC")$Dilution.Factor
subset(this.subset,Time==0)$Response/1*subset(this.subset,Time==0)$Dilution.Factor

## -----------------------------------------------------------------------------
level2$Technical.Replicates <- 1
colnames(level2)[which(colnames(level2) == "Std.Conc")] <- "Test.Compound.Conc"

## ----MLE, eval=TRUE-----------------------------------------------------------
## Use data.in to specify input level-2 data from R session instead of using FILENAME to read in external .tsv file. 
## `output.res = FLASE` prevents the exporting of the level-3 result. 
level3 <- calc_clint_point(data.in = level2, 
                           output.res = FALSE)

## ----Bayes, eval=FALSE--------------------------------------------------------
#  library(invitroTKstats)
#  setwd("c:/users/jwambaug/git/invitroTKstats/working/KreutzPFAS")
#  
#  level4 <- calc_clint(FILENAME="KreutzPFAS",
#                            NUM.CORES=8,
#                            JAGS.PATH="C:/Users/jwambaug/AppData/Local/JAGS/JAGS-4.3.0/x64")

